import os
import numpy as np
import torch
from lux.game import Game
from collections import defaultdict


path = '/kaggle_simulations/agent' if os.path.exists('/kaggle_simulations') else 'agent'
unit_model = torch.jit.load(f'{path}/unit_model.pth')
city_model = torch.jit.load(f'{path}/city_model.pth')
unit_model.eval()
city_model.eval()
resource_to_layer = {'wood': 16, 'coal': 17, 'uranium': 18}


def to_unit_id(unit_str):
    return int(unit_str.split("_")[1])


# Input for Neural Network
def make_input(obs):
    player, step, updates, width, height, actions = obs
    x_shift = (32 - width) // 2
    y_shift = (32 - height) // 2
    cities = {}
    team_to_num_city = defaultdict(int) 
    
    unit_id_to_label = dict(actions)
    
    b = np.zeros((20, 32, 32), dtype=np.float32)
    gf = np.zeros((7, 4, 4), dtype=np.float32)
    label = np.zeros((6, 32, 32), dtype=np.float32)
    
    for update in updates:
        strs = update.split(' ')
        input_identifier = strs[0]
        
        if input_identifier == 'u':
            x = int(strs[4]) + x_shift
            y = int(strs[5]) + y_shift
            wood = int(strs[7])
            coal = int(strs[8])
            uranium = int(strs[9])

            # Units
            team = int(strs[2])
            unit_id = to_unit_id(strs[3])
            cooldown = float(strs[6])
            idx = (team - player) % 2 * 6
            b[idx:idx + 6, x, y] = (
                1,
                cooldown / 6,
                (wood + coal + uranium) / 100,
                wood / 100,
                coal / 100,
                uranium / 100,
            )
            
            if unit_id in unit_id_to_label:
                lb = unit_id_to_label[unit_id]
                need_label = True
                if lb == CENTER_LABEL and random.random() > 0.15:
                    need_label = False
                if need_label:
                    label[lb, x, y] = 1
    
        elif input_identifier == 'ct':
            # CityTiles
            team = int(strs[1])
            city_id = strs[2]
            x = int(strs[3]) + x_shift
            y = int(strs[4]) + y_shift
            idx = 12 + (team - player) % 2 * 2
            b[idx:idx + 2, x, y] = (
                1,
                cities[city_id]
            )
            team_to_num_city[team] += 1

        elif input_identifier == 'r':
            # Resources
            r_type = strs[1]
            x = int(strs[2]) + x_shift
            y = int(strs[3]) + y_shift
            amt = int(float(strs[4]))
            b[resource_to_layer[r_type], x, y] = amt / 800

        elif input_identifier == 'rp':
            # Research Points
            team = int(strs[1])
            rp = int(strs[2])
            gf[(team - player) % 2, :] = min(rp, 200) / 200

        elif input_identifier == 'c':
            # Cities
            city_id = strs[2]
            fuel = float(strs[3])
            lightupkeep = float(strs[4])
            cities[city_id] = min(fuel / lightupkeep, 10) / 10
    
    # Day/Night Cycle
    is_day = (step % 40) < 30
    gf[2, :] = is_day
    gf[3, :] = (step % 40) / 30 if is_day else ((step % 40) - 30) / 10
    # Turns
    gf[4, :] = step / 360
    # Num city
    gf[5, :] = team_to_num_city[player] / (width * height)
    gf[6, :] = team_to_num_city[1-player] / (width * height)
    # Map Size
    b[19, x_shift:32 - x_shift, y_shift:32 - y_shift] = 1
    
    return b, gf, x_shift, y_shift, label


def make_city_input(obs):
    player = obs["index"]
    step = obs["step"]
    updates = obs["updates"]
    width = obs["width"]
    height = obs["height"]

    x_shift = (32 - width) // 2
    y_shift = (32 - height) // 2
    cities = {}
    team_to_num_city = defaultdict(int)

    b = np.zeros((20, 32, 32), dtype=np.float32)
    gf = np.zeros((7, 4, 4), dtype=np.float32)

    for update in updates:
        strs = update.split(' ')
        input_identifier = strs[0]

        if input_identifier == 'u':
            x = int(strs[4]) + x_shift
            y = int(strs[5]) + y_shift
            wood = int(strs[7])
            coal = int(strs[8])
            uranium = int(strs[9])

            # Units
            team = int(strs[2])
            unit_id = to_unit_id(strs[3])
            cooldown = float(strs[6])
            idx = (team - player) % 2 * 6
            b[idx:idx + 6, x, y] = (
                1,
                cooldown / 6,
                (wood + coal + uranium) / 100,
                wood / 100,
                coal / 100,
                uranium / 100,
            )

        elif input_identifier == 'ct':
            # CityTiles
            team = int(strs[1])
            city_id = strs[2]
            x = int(strs[3]) + x_shift
            y = int(strs[4]) + y_shift
            idx = 12 + (team - player) % 2 * 2
            b[idx:idx + 2, x, y] = (
                1,
                cities[city_id]
            )
            team_to_num_city[team] += 1

        elif input_identifier == 'r':
            # Resources
            r_type = strs[1]
            x = int(strs[2]) + x_shift
            y = int(strs[3]) + y_shift
            amt = int(float(strs[4]))
            b[resource_to_layer[r_type], x, y] = amt / 800

        elif input_identifier == 'rp':
            # Research Points
            team = int(strs[1])
            rp = int(strs[2])
            gf[(team - player) % 2, :] = min(rp, 200) / 200

        elif input_identifier == 'c':
            # Cities
            city_id = strs[2]
            fuel = float(strs[3])
            lightupkeep = float(strs[4])
            cities[city_id] = min(fuel / lightupkeep, 10) / 10

    # Map Size
    b[19, x_shift:32 - x_shift, y_shift:32 - y_shift] = 1

    # Day/Night Cycle
    is_day = (step % 40) < 30
    gf[2, :] = is_day
    gf[3, :] = (step % 40) / 30 if is_day else ((step % 40) - 30) / 10
    # Turns
    gf[4, :] = step / 360
    # Num city
    gf[5, :] = team_to_num_city[player] / (width * height)
    gf[6, :] = team_to_num_city[1 - player] / (width * height)

    return b, gf, x_shift, y_shift


game_state = None
def get_game_state(observation):
    global game_state
    
    if observation["step"] == 0:
        game_state = Game()
        game_state._initialize(observation["updates"])
        game_state._update(observation["updates"][2:])
        game_state.id = observation["player"]
    else:
        game_state._update(observation["updates"])
    return game_state


def in_city(pos):    
    try:
        city = game_state.map.get_cell_by_pos(pos).citytile
        return city is not None and city.team == game_state.id
    except:
        return False


def call_func(obj, method, args=[]):
    return getattr(obj, method)(*args)


city_actions = [
    "build_worker", "research", "none"
]



unit_actions = [('move', 'n'), ('move', 's'), ('move', 'w'), ('move', 'e'), ('build_city',), ('move', 'c')]
def get_action(policy, unit, dest):
    for label in np.argsort(policy)[::-1]:
        act = unit_actions[label]
        pos = unit.pos.translate(act[-1], 1) or unit.pos
        if pos not in dest or in_city(pos):
            return call_func(unit, *act), pos 
            
    return unit.move('c'), unit.pos


def agent(observation, configuration):
    global game_state
    
    game_state = get_game_state(observation)    
    player = game_state.players[observation.player]
    actions = []
    
    # City Actions
    with torch.no_grad():
        raw_input = {
            "index": observation["player"],
            "step": observation["step"],
            "updates": observation["updates"],
            "width": observation["width"],
            "height": observation["height"],
        }
        state, gf, x_shift, y_shift = make_city_input(raw_input)
        state = torch.from_numpy(state).unsqueeze(0)
        gf = torch.from_numpy(gf).unsqueeze(0)
        city_policy = city_model(state, gf)
        city_policy = city_policy.squeeze(0).numpy()

    unit_count = len(player.units)
    for city in player.cities.values():
        for city_tile in city.citytiles:
            if city_tile.can_act():
                p = city_policy[:, x_shift + city_tile.pos.x, y_shift + city_tile.pos.y]
                for label in np.argsort(p)[::-1]:
                    command = city_actions[label]
                    if command == "none":
                        break
                    elif command == "build_worker":
                        if unit_count >= player.city_tile_count:
                            continue
                        actions.append(city_tile.build_worker())
                        unit_count += 1
                        break
                    elif command == "research":
                        if player.researched_uranium():
                            continue
                        actions.append(city_tile.research())
                        player.research_points += 1
                        break
                    else:
                        raise ValueError(f"Unknown command {command}")
    
    # Worker Actions
    dest = []
    raw_input = (
        observation["player"],
        observation["step"],
        observation["updates"],
        observation["width"],
        observation["height"],
        [],
    )
    state, gf, x_shift, y_shift, _ = make_input(raw_input)
    with torch.no_grad():
        p = unit_model(torch.from_numpy(state).unsqueeze(0), torch.from_numpy(gf).unsqueeze(0))
    policy = p.squeeze(0).numpy()
        
    for unit in player.units:
        if unit.can_act(): # and (game_state.turn % 40 < 30 or not in_city(unit.pos)):
            action, pos = get_action(policy[:, x_shift + unit.pos.x, y_shift + unit.pos.y], unit, dest)
            actions.append(action)
            dest.append(pos)

    return actions
